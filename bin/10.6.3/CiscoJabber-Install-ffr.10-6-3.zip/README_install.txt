=========================================
Cisco Jabber for Windows 10.6.3 Installer
=========================================
  
CiscoJabber-Install-ffr.10-6-3.zip

Contains MSI for Build Number 10.6.3.61622
 - CiscoJabberSetup.msi
